<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    </head>
    <body>
        <h2>Pendaftaran Siswa Baru</h2>
        <h1>Digital Talent</h1>
        <a href="form-daftar.php">
                <input type="button" class="btn btn-secondary" value="Daftar Baru">
        </a>
        <a href="list-siswa.php">
                <input type="button" class="btn btn-secondary" value="Pendaftar">
        </a>
    </body>    
</html>